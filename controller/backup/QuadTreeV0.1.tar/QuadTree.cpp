#include "QuadTree.h"

/// BucketNode CLASS
BucketNode::BucketNode(){
	prefMsk_src.push_back(0);
	prefMsk_src.push_back(0);
	prefMsk_dst.push_back(0);
	prefMsk_dst.push_back(0);
}

BucketNode::BucketNode(Pref_Msk_T srcPM, Pref_Msk_T dstPM, vector<short int> rLst){
	prefMsk_src = srcPM;
	prefMsk_dst = dstPM;
	rule_list = rLst;
}

void BucketNode::quadCut(const RuleList& ruleRec, vector<BucketNode*> &cutNodeList){
	unsigned int cutSize = 4;

	bool effective = false; // if there's no change by cutting things, then it's not effective

	for (unsigned int idx = 0; idx < cutSize; idx++){
		unsigned int newPref_src = prefMsk_src[0] + ((idx/2) << (31-prefMsk_src[1]));
		unsigned int newPref_dst = prefMsk_dst[0] + ((idx - (idx/2)*2) << (31-prefMsk_dst[1]));
		
		Pref_Msk_T newPrefM_src;
		Pref_Msk_T newPrefM_dst;
		newPrefM_src.push_back(newPref_src);
		newPrefM_src.push_back(prefMsk_src[1]+1);
		newPrefM_dst.push_back(newPref_dst);
		newPrefM_dst.push_back(prefMsk_dst[1]+1);// get the Pref/Mask for son node

		vector<short int> newRule_list;

		// split the parent node and find matched rules in son buckets
		for (unsigned int ruleIdx = 0; ruleIdx < rule_list.size(); ruleIdx++){
			if ((ruleRec.handle[rule_list[ruleIdx]]).match_rule(newPrefM_src, newPrefM_dst))
				newRule_list.push_back(rule_list[ruleIdx]);
			else
				effective = true; // if there's some rule not included, then cutting reduce rule 
		}
		
		if (newRule_list.size() != 0) // exclude empty bucket
			cutNodeList[idx] = new BucketNode(newPrefM_src, newPrefM_dst, newRule_list);
		else
			cutNodeList[idx] = NULL;
	}

	if (!effective) // cut does not split the rules. abort the cut
		for (unsigned int idx = 0; idx < cutSize; idx++){
			delete cutNodeList[idx];
			cutNodeList[idx] = NULL;
		}
}

string BucketNode::getPrintStr(){
	return get_dotDeci(prefMsk_src) + "\t" + get_dotDeci(prefMsk_dst) + "\t" + boost::lexical_cast<string> (rule_list.size());
}

/// BucketRec CLASS
BucketRec::BucketRec(const RuleList& ruleRec, const int &max_size, const int & min_scope):ruleRecord(ruleRec), THRESHOLD(max_size), MIN_BUCKET_SCOPE(min_scope){
	rootBucket = new BucketNode(); // setting this part can resize the beginning scope
	Pref_Msk_T emptyPrefM;
	emptyPrefM.push_back(0);
	emptyPrefM.push_back(0);
	
	for (unsigned short int ruleIdx = 0; ruleIdx < (unsigned) ruleRec.size; ruleIdx ++){
		rootBucket->rule_list.push_back(ruleIdx);
	}

}

void BucketRec::obtainBuckets(ofstream & bucketFile, BucketNode * dealNode){

	bool isLeafNode = true; 
	
	if ((dealNode->prefMsk_src[1] <= MIN_BUCKET_SCOPE-1) && (dealNode->rule_list.size() > THRESHOLD)){ // max_size or min_scope reached, do not cut
		vector<BucketNode *> sonBucket_lst;
		for (int i = 0; i<4; i++)
			sonBucket_lst.push_back(NULL);

		dealNode->quadCut(ruleRecord, sonBucket_lst);
		for (int i = 0; i<4; i++){ 
			if (sonBucket_lst[i]!=NULL){ // has son, valid cut
				obtainBuckets(bucketFile, sonBucket_lst[i]); // DFS search
				isLeafNode = false;
			}
		}
	}

	if (isLeafNode){ // leaf node, print out
		bucketFile<<dealNode->getPrintStr()<<endl;
	}
	
	delete dealNode; // release the dynamic alloc son;
}

void BucketRec::writeBucket(string fileName){
	ofstream bucketFile;
	bucketFile.open(fileName.c_str());
	obtainBuckets(bucketFile, rootBucket);
	bucketFile.close();
}

