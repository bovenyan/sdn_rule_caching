#include "tools.h"
#include <iostream>
//using namespace boost::asio;
using namespace std;

string get_dotDeci(Pref_Msk_T ip_i){
	boost::asio::ip::address_v4 ip_a(ip_i[0]);

	return ip_a.to_string() + "/" + boost::lexical_cast<string>(ip_i[1]);
}

unsigned int maskIP(string ip_s, unsigned int mask){
	boost::asio::ip::address_v4 ip_a = boost::asio::ip::address_v4::from_string(ip_s);
	unsigned int maskAnd = (~unsigned(0)) << (32-mask);
	return ip_a.to_ulong() & maskAnd;
}

bool match(const Pref_Msk_T &bucket_src, const Pref_Msk_T &bucket_dst, const Pref_Msk_T &rule_src, const Pref_Msk_T &rule_dst){
	// obtain the shorter mask of rule mask and bucket mask. 
	unsigned int srcMsk = 0;
	(bucket_src[1] > rule_src[1])?(srcMsk = rule_src[1]):(srcMsk = bucket_src[1]);
	unsigned int dstMsk = 0;
	(bucket_dst[1] > rule_dst[1])?(dstMsk = rule_dst[1]):(dstMsk = bucket_dst[1]);
	

	if ( (bucket_src[0] & ((~unsigned(0)) << (32-srcMsk))) != (rule_src[0] & ((~unsigned(0)) << (32-srcMsk))))
		if (srcMsk!= 0)
			return false;
	
	if ( (bucket_dst[0] & ((~unsigned(0)) << (32-dstMsk))) != (rule_dst[0] & ((~unsigned(0)) << (32-dstMsk))))
		if (dstMsk!= 0)
			return false;

	return true;
}


bool match_check(const Pref_Msk_T &bucket_src, const Pref_Msk_T &bucket_dst, const Pref_Msk_T &rule_src, const Pref_Msk_T &rule_dst, bool &default_rule){
	unsigned int srcMsk = 0;
	(bucket_src[1] > rule_src[1])?(srcMsk = rule_src[1]):(srcMsk = bucket_src[1]);
	unsigned int dstMsk = 0;
	(bucket_dst[1] > rule_dst[1])?(dstMsk = rule_dst[1]):(dstMsk = bucket_dst[1]);


	if ( (bucket_src[0] & ((~unsigned(0)) << (32-srcMsk))) != (rule_src[0] & ((~unsigned(0)) << (32-srcMsk))))
		if (srcMsk!= 0)
			return false;
	
	if ( (bucket_dst[0] & ((~unsigned(0)) << (32-dstMsk))) != (rule_dst[0] & ((~unsigned(0)) << (32-dstMsk))))
		if (dstMsk!= 0)
			return false;
	
	if ((srcMsk == rule_src[1]) && (dstMsk == rule_dst[1]))
		default_rule = true; // this rule is covering the whole bucket
	else
		default_rule = false;
	return true;
}

bool rule_bucket_redu(const Pref_Msk_T & bucketSrc, const Pref_Msk_T & bucketDst, const Pref_Msk_T & hiRule_src, const Pref_Msk_T & hiRule_dst, const Pref_Msk_T & rule_src, const Pref_Msk_T & rule_dst){
	unsigned int srcMsk = 0;
	unsigned int ruleSrcMsk = 0;
	unsigned int hiRuleSrcMsk = 0;
	(bucketSrc[1] > rule_src[1])?(ruleSrcMsk = bucketSrc[1]):(ruleSrcMsk = rule_src[1]);
	(bucketSrc[1] > hiRule_src[1])?(hiRuleSrcMsk = bucketSrc[1]):(hiRuleSrcMsk = hiRule_src[1]);
	(ruleSrcMsk > hiRuleSrcMsk)?(srcMsk = ruleSrcMsk):(srcMsk = hiRuleSrcMsk);

	
	unsigned int dstMsk = 0;
	unsigned int ruleDstMsk = 0;
	unsigned int hiRuleDstMsk = 0;
	(bucketDst[1] > rule_dst[1])?(ruleDstMsk = bucketDst[1]):(ruleDstMsk = rule_dst[1]);
	(bucketDst[1] > hiRule_dst[1])?(hiRuleDstMsk = bucketDst[1]):(hiRuleDstMsk = hiRule_dst[1]);
	(ruleDstMsk > hiRuleDstMsk)?(dstMsk = ruleDstMsk):(dstMsk = hiRuleDstMsk);

	if (srcMsk != 0){
		if ( (rule_src[0] & (~unsigned(0) << (32 - srcMsk))) != (hiRule_src[0] & (~unsigned(0) << (32 - srcMsk))) )
			return false;
	}
	else{
		if (rule_src[0] != hiRule_src[0])
			return false;
	}

	
	if (dstMsk != 0){
		if ( (rule_dst[0] & (~unsigned(0) << (32 - dstMsk))) != (hiRule_dst[0] & (~unsigned(0) << (32 - dstMsk))) )
			return false;
	}
	else{
		if (rule_dst[0] != hiRule_dst[0])
			return false;
	}

	return true;
}

Range_T to_range(const Pref_Msk_T & prefmsk){
	Range_T range;
	range.push_back(prefmsk[0]);
	if(prefmsk[1] != 0)
		range.push_back(prefmsk[0] + ((~unsigned(0)) >> (32 - prefmsk[0])));
	else
		range.push_back(~unsigned(0));
	return range;
}
