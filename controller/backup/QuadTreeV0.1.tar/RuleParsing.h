#ifndef __PARSER_H
#define __PARSER_H

#include <string>
#include <vector>
#include <fstream>
#include <boost/algorithm/string.hpp> 
#include "tools.h"
#include <iostream>

using namespace std;


class OneRule;

// parsing the rule file into a OneRule type vector, remove redundancy
class RuleList{
	typedef vector<OneRule> RuleRec_T;

	private:
	OneRule parseAline (string); // parse each line of rule file
	
	public:
	int size;
	RuleRec_T handle; // rule vector handle
	RuleList(const char*);
	void removeRedundant(); // remove the redundant rules
	~RuleList();
};

// structure for one rule
class OneRule{
	public:
	
	vector<unsigned int> srcIP_i;
	vector<unsigned int> dstIP_i;

	vector<unsigned int> srcP_i;
	vector<unsigned int> dstP_i;
	unsigned int protocol;

	OneRule(){
		srcIP_i.push_back(0);
		srcIP_i.push_back(0);
		dstIP_i.push_back(0);
		dstIP_i.push_back(0);

		srcP_i.push_back(0);
		srcP_i.push_back(0);
		dstP_i.push_back(0);
		dstP_i.push_back(0);
		protocol = 0;
	}

	// comparing equal rules
	bool operator==(const OneRule& rule){
		if (srcIP_i[0] != rule.srcIP_i[0])
			return false;
		if (srcIP_i[1] != rule.srcIP_i[1])
			return false;

		if (dstIP_i[0] != rule.dstIP_i[0])
			return false;
		if (dstIP_i[1] != rule.dstIP_i[1])
			return false;

		if (srcP_i[0] != rule.srcP_i[0])
			return false;
		if (srcP_i[1] != rule.srcP_i[1])
			return false;
		if (dstP_i[0] != rule.dstP_i[0])
			return false;
		if (dstP_i[1] != rule.dstP_i[1])
			return false;
		if (protocol != rule.protocol)
			return false;

		return true;
	}
	
	// check whether the rule match a certain bucket
	bool match_rule(vector<unsigned int> &src_preMsk, vector<unsigned int> &dst_preMsk) const{
		return match(src_preMsk, dst_preMsk, srcIP_i, dstIP_i);
	}
	
	// for debug: print out parsed rule
	void print(){
		cout << "srcIP:" << get_dotDeci(srcIP_i);
		cout << " dstIP:" << get_dotDeci(dstIP_i);
		cout << " srcPort:["<<srcP_i[0]<<","<<srcP_i[1]<<"]";
		cout << " dstPort:["<<dstP_i[0]<<","<<dstP_i[1]<<"]";
		cout << " proto:" << protocol;
		cout << endl;
	}
};

#endif
