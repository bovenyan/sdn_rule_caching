#include "RuleParsing.h"
#include "tools.h"
#include "QuadTree.h"

int main(){
	RuleList ruleRec("Filters10k");
	ruleRec.removeRedundant();
	
	cout<<"Non-redundant rule records in the rule file is: "<<ruleRec.size<<endl;
	//test insert and remove
	//for (int i =0; i< ruleRec.size; i++)
	//	ruleRec.handle[i].print();
	cout<<"finish parse"<<endl;

	BucketRec bucketGen(ruleRec, 200, 10); //NOTE: SETTING HERE TO CUSTOMIZE BUCKET SIZE AND MINIMUM SCOPE. advice: do not use bucket scope larger than 11, given 10k rules this will exhaust your memory

	bucketGen.writeBucket("BucketList.txt");
	

	//test matching
	/*
	string ip= "12.147.29.76";
	vector<unsigned int> bucket_s;
	bucket_s.push_back(maskIP(ip,30));
	bucket_s.push_back(30);

	ip= "1.86.177.0";
	vector<unsigned int> bucket_d;
	bucket_d.push_back(maskIP(ip,24));
	bucket_d.push_back(24);
	ruleRec.handle[3].print();	
	cout<<ruleRec.handle[3].match_rule(bucket_s, bucket_d)<<endl;
	*/

	return 0;
}
