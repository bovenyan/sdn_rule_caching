#ifndef __TOOLS_H
#define __TOOLS_H

#include <boost/lexical_cast.hpp>
#include <boost/asio.hpp>
#include <vector>
#include <string>

using namespace std;

string get_dotDeci(vector<unsigned int>); // transfer pref/mask to dot deci string

unsigned int maskIP(string, unsigned int); // transfer dot deci string to pref/mask 

bool match(const vector<unsigned int> &, const vector<unsigned int> &, const vector<unsigned> &, const vector<unsigned int> &); // check whether certain rule matches certain bucket

#endif
