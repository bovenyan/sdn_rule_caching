#ifndef __PARSER_H
#define __PARSER_H

#include <string>
#include <vector>
#include <fstream>
#include <boost/algorithm/string.hpp> 
#include "tools.h"
#include <iostream>

using namespace std;


class OneRule;
class RangeRule;


// parsing the rule file into a OneRule type vector, remove redundancy
class RuleList{
	typedef vector<OneRule> RuleRec_T;

	private:
	OneRule parseAline (string); // parse each line of rule file
	
	public:
	int size;
	RuleRec_T handle; // rule vector handle
	RuleList(const char*);
	void removeRedundant(); // remove the redundant rules
	~RuleList();
};

// structure for one rule
class OneRule{
	public:
	
	Pref_Msk_T srcIP_i;
	Pref_Msk_T dstIP_i;

	Range_T srcP_i;
	Range_T dstP_i;
	unsigned int protocol;

	OneRule(){
		srcIP_i.push_back(0);
		srcIP_i.push_back(0);
		dstIP_i.push_back(0);
		dstIP_i.push_back(0);

		srcP_i.push_back(0);
		srcP_i.push_back(0);
		dstP_i.push_back(0);
		dstP_i.push_back(0);
		protocol = 0;
	}

	// comparing equal rules
	bool operator==(const OneRule& rule){
		if (srcIP_i[0] != rule.srcIP_i[0])
			return false;
		if (srcIP_i[1] != rule.srcIP_i[1])
			return false;

		if (dstIP_i[0] != rule.dstIP_i[0])
			return false;
		if (dstIP_i[1] != rule.dstIP_i[1])
			return false;

		if (srcP_i[0] != rule.srcP_i[0])
			return false;
		if (srcP_i[1] != rule.srcP_i[1])
			return false;
		if (dstP_i[0] != rule.dstP_i[0])
			return false;
		if (dstP_i[1] != rule.dstP_i[1])
			return false;
		if (protocol != rule.protocol)
			return false;

		return true;
	}
	
	// check whether the rule match a certain bucket
	bool match_rule(Pref_Msk_T &src_preMsk, Pref_Msk_T &dst_preMsk) const{
		return match(src_preMsk, dst_preMsk, srcIP_i, dstIP_i);
	}
	
	// check whether the rule match a certain bucket, if is default rule of the bucket, is_def_rule
	bool match_rule_defaultCheck(Pref_Msk_T &src_preMsk, Pref_Msk_T &dst_preMsk, bool & is_def_rule) const{
		return match_check(src_preMsk, dst_preMsk, srcIP_i, dstIP_i, is_def_rule);
	}
	
	// check whether the rule is redundant because of higher level masking rule
	bool bucket_red(Pref_Msk_T & bucketSrc, Pref_Msk_T & bucketDst, const OneRule & hiRule) const{
		return rule_bucket_redu(bucketSrc, bucketDst, hiRule.srcIP_i, hiRule.dstIP_i, srcIP_i, dstIP_i);	
	}


	// for debug: print out parsed rule
	void print(){
		cout << "srcIP:" << get_dotDeci(srcIP_i);
		cout << " dstIP:" << get_dotDeci(dstIP_i);
		cout << " srcPort:["<<srcP_i[0]<<","<<srcP_i[1]<<"]";
		cout << " dstPort:["<<dstP_i[0]<<","<<dstP_i[1]<<"]";
		cout << " proto:" << protocol;
		cout << endl;
	}
};

#endif
