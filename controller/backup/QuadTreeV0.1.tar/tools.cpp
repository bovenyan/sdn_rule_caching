#include "tools.h"
#include <iostream>
//using namespace boost::asio;
using namespace std;

string get_dotDeci(vector<unsigned int> ip_i){
	boost::asio::ip::address_v4 ip_a(ip_i[0]);

	return ip_a.to_string() + "/" + boost::lexical_cast<string>(ip_i[1]);
}

unsigned int maskIP(string ip_s, unsigned int mask){
	boost::asio::ip::address_v4 ip_a = boost::asio::ip::address_v4::from_string(ip_s);
	unsigned int maskAnd = (~unsigned(0)) << (32-mask);
	return ip_a.to_ulong() & maskAnd;
}

bool match(const vector<unsigned int> &bucket_src, const vector<unsigned int> &bucket_dst, const vector<unsigned int> &rule_src, const vector<unsigned int> &rule_dst){
	// obtain the shorter mask of rule mask and bucket mask. 
	unsigned int srcMsk = 0;
	(bucket_src[1] > rule_src[1])?(srcMsk = rule_src[1]):(srcMsk = bucket_src[1]);
	unsigned int dstMsk = 0;
	(bucket_dst[1] > rule_dst[1])?(dstMsk = rule_dst[1]):(dstMsk = bucket_dst[1]);
	

	if ( (bucket_src[0] & ((~unsigned(0)) << (32-srcMsk))) != (rule_src[0] & ((~unsigned(0)) << (32-srcMsk))))
		if (srcMsk!= 0)
			return false;
	
	if ( (bucket_dst[0] & ((~unsigned(0)) << (32-dstMsk))) != (rule_dst[0] & ((~unsigned(0)) << (32-dstMsk))))
		if (dstMsk!= 0)
			return false;

	return true;
}
