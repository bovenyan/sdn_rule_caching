#ifndef __TOOLS_H
#define __TOOLS_H

#include <boost/lexical_cast.hpp>
#include <boost/asio.hpp>
#include <vector>
#include <string>

using namespace std;

typedef vector<unsigned int> Pref_Msk_T;
typedef vector<unsigned int> Range_T;

string get_dotDeci(Pref_Msk_T); // transfer pref/mask to dot deci string

unsigned int maskIP(string, unsigned int); // transfer dot deci string to pref/mask 

bool match(const Pref_Msk_T &, const Pref_Msk_T &, const Pref_Msk_T &, const Pref_Msk_T &); // check whether certain rule matches certain bucket

bool match_check(const Pref_Msk_T &, const Pref_Msk_T &, const Pref_Msk_T &, const Pref_Msk_T &, bool &); // check whether certain rule is default that mask whole bucket

bool rule_bucket_redu(const Pref_Msk_T &, const Pref_Msk_T &, const Pref_Msk_T &, const Pref_Msk_T &, const Pref_Msk_T &, const Pref_Msk_T &); // check whether a rule is redundant because of covering rule

Range_T to_range(const Pref_Msk_T &);
#endif
